Reduces the effects of lag on certain aspects of the game, such as weaving and statuses.

Helps with weaving in a similar way to [XivAlexander](https://github.com/Soreepeong/XivAlexander) except without ping or opcodes.
If you use both, the animation lock compensation feature will automatically disable itself to prevent cheating.
However, other features may freely be used at the same time.

For use with [FFXIVQuickLauncher](https://github.com/goatcorp/FFXIVQuickLauncher).

For installation instructions, please see my [custom plugin repository](https://github.com/UnknownX7/DalamudPluginRepo).
